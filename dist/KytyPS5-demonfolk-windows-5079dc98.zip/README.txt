KytyPS5 Demonfolk Windows build

Emulator source: 5079dc98e8956f86ec903acc5da047df4a904068.
The launcher is the existing portable launcher from the player's folder; it was built earlier than the emulator.
Unzip to a writable folder and run launcher.exe. Choose your own legally obtained game directory.
The included PPSA01342 profile uses 1080p rendering, full textures, shader warmup, and reduced shadows.
Game files, saves, personal settings and GPU-specific shader caches are not included. Shaders and pipelines
may compile during play until caches are populated, and warmup can use substantial memory.
This executable was built with native CPU optimization and may not run on every Windows machine.
Source dependencies are Git submodules: git submodule update --init --recursive.
